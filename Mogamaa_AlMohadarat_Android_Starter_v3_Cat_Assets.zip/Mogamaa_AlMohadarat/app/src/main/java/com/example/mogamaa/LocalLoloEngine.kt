package com.example.mogamaa

/**
 * Demo-only local fallback. This is NOT a real LLM.
 * Replace this implementation with a tested on-device model runtime for true offline AI.
 */
class LocalLoloEngine {
    fun answer(question: String): String {
        val q = question.trim()
        if (q.isEmpty()) return "اكتب سؤالك يا بطل 🐾"
        return "أنا لولو 🐱 — النسخة الحالية تعمل محليًا، لكن محرك الذكاء الاصطناعي الحقيقي لم يُضف بعد. " +
            "لإجابة دقيقة، أضف نموذجًا محليًا متوافقًا أو اربطني بخادم آمن. " +
            "سؤالك: «$q»"
    }
}
