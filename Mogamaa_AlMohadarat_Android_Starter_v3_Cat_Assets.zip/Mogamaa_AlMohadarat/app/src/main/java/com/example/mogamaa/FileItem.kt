package com.example.mogamaa

data class FileItem(
    val name: String,
    val uri: String,
    val mimeType: String?
)
