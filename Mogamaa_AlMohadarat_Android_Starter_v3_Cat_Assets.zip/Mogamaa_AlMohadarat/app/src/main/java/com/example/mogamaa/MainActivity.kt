package com.example.mogamaa

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Burgundy = Color(0xFF9D174D)
private val BurgundyDeep = Color(0xFF3B1025)
private val Background = Color(0xFF080709)
private val SurfaceGlass = Color(0xFF171217)
private val MutedPink = Color(0xFFE7A0BD)
private val SoftWhite = Color(0xFFF7EAF0)

class MainActivity : ComponentActivity() {
    private val subjects = listOf("هندسة", "رعاية", "ميكرو", "كيمياء", "محاصيل", "بساتين")
    private val prefs by lazy { getSharedPreferences("mogamaa_local", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 7, 9)
        window.navigationBarColor = android.graphics.Color.rgb(8, 7, 9)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Burgundy, secondary = MutedPink,
                background = Background, surface = SurfaceGlass,
                onBackground = SoftWhite, onSurface = SoftWhite
            )) { AppScreen() }
        }
    }

    private fun filesFor(subject: String): List<FileItem> {
        val array = JSONArray(prefs.getString("files_$subject", "[]"))
        return (0 until array.length()).mapNotNull { i ->
            runCatching {
                val o = array.getJSONObject(i)
                FileItem(o.getString("name"), o.getString("uri"), o.optString("mime").takeIf { it.isNotBlank() })
            }.getOrNull()
        }
    }

    private fun saveFiles(subject: String, files: List<FileItem>) {
        val array = JSONArray()
        files.forEach { array.put(JSONObject().put("name", it.name).put("uri", it.uri).put("mime", it.mimeType ?: "")) }
        prefs.edit().putString("files_$subject", array.toString()).apply()
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && index >= 0) return cursor.getString(index) ?: "ملف"
        }
        return uri.lastPathSegment ?: "ملف"
    }

    @Composable
    private fun AppScreen() {
        var selectedSubject by remember { mutableStateOf<String?>(null) }
        var showLolo by remember { mutableStateOf(false) }
        var refresh by remember { mutableIntStateOf(0) }
        val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            val subject = selectedSubject ?: return@rememberLauncherForActivityResult
            val existing = filesFor(subject).toMutableList()
            uris.forEach { uri ->
                runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                val item = FileItem(displayName(uri), uri.toString(), contentResolver.getType(uri))
                if (existing.none { it.uri == item.uri }) existing.add(item)
            }
            saveFiles(subject, existing)
            refresh++
        }
        Surface(Modifier.fillMaxSize(), color = Background) {
            when {
                showLolo -> LoloScreen(onBack = { showLolo = false })
                selectedSubject != null -> {
                    val subject = selectedSubject!!
                    key(subject, refresh) {
                        SubjectScreen(subject, filesFor(subject), { selectedSubject = null },
                            { pickFiles.launch(arrayOf("*/*")) },
                            { item -> saveFiles(subject, filesFor(subject).filterNot { it.uri == item.uri }); refresh++ },
                            { item -> runCatching {
                                startActivity(Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(Uri.parse(item.uri), item.mimeType ?: "*/*")
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                })
                            } })
                    }
                }
                else -> HomeScreen(subjects, { selectedSubject = it }, { showLolo = true })
            }
        }
    }

    @Composable
    private fun HomeScreen(subjects: List<String>, onSubject: (String) -> Unit, onLolo: () -> Unit) {
        Column(
            Modifier.fillMaxSize().background(Background).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            // Hero banner inspired by the approved cat-themed mockup
            Box(
                Modifier.fillMaxWidth().height(205.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF160B12), Color(0xFF301021), Color(0xFF09080A))))
                    .padding(18.dp)
            ) {
                Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.73f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.School, null, tint = MutedPink, modifier = Modifier.size(30.dp))
                        Text("🐾", fontSize = 25.sp)
                    }
                    Text("مجمع المحاضرات", color = SoftWhite, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 34.sp)
                    Text("تانية زراعة • شعبة عامة", color = MutedPink, fontSize = 15.sp)
                    Text("♡ بالعلم نحقق أحلامنا", color = Color(0xFFD16B98), fontSize = 13.sp)
                }
                Image(
                    painter = painterResource(R.drawable.hero_cat),
                    contentDescription = "قطة مجمع المحاضرات",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.align(Alignment.CenterEnd).offset(x = 8.dp, y = 18.dp)
                        .size(width = 178.dp, height = 165.dp).clip(RoundedCornerShape(28.dp))
                )
                Row(Modifier.align(Alignment.TopEnd), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    RoundIcon(Icons.Default.Search, "بحث") { }
                    RoundIcon(Icons.Default.Settings, "الإعدادات") { }
                }
            }

            Surface(
                color = Color(0xFF171016),
                shape = RoundedCornerShape(22.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF642342)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🐾", fontSize = 35.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("أهلاً بيك! 👋", color = SoftWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("اختار المادة اللي عايز تذاكرها، أو استخدم مساعدك الذكي لولو AI", color = Color(0xFFD5C5CD), fontSize = 12.sp, lineHeight = 18.sp)
                    }
                    Text("♡", color = MutedPink, fontSize = 26.sp)
                }
            }

            Text("موادك الدراسية", color = SoftWhite, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            subjects.chunked(3).forEachIndexed { rowIndex, rowSubjects ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowSubjects.forEach { subject ->
                        val icon = when (subject) {
                            "هندسة" -> Icons.Default.Agriculture
                            "رعاية" -> Icons.Default.FavoriteBorder
                            "ميكرو" -> Icons.Default.Biotech
                            "كيمياء" -> Icons.Default.Science
                            "محاصيل" -> Icons.Default.Spa
                            else -> Icons.Default.Park
                        }
                        Card(
                            modifier = Modifier.weight(1f).height(145.dp).clickable { onSubject(subject) },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF171116)),
                            shape = RoundedCornerShape(20.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF563044))
                        ) {
                            Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                Box(Modifier.size(48.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Burgundy, BurgundyDeep))), contentAlignment = Alignment.Center) {
                                    Icon(icon, null, tint = SoftWhite, modifier = Modifier.size(27.dp))
                                }
                                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(subject, color = SoftWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                    Text("محاضرات وملفات", color = Color(0xFFD5C5CD), fontSize = 10.sp)
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    Icon(Icons.Default.ArrowForward, null, tint = MutedPink, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                    repeat(3 - rowSubjects.size) { Spacer(Modifier.weight(1f)) }
                }
            }

            Surface(
                color = Color(0xFF1B0D16),
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF84274F)),
                modifier = Modifier.fillMaxWidth().clickable { onLolo() }
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(76.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Burgundy, Color(0xFF1C0B14)))), contentAlignment = Alignment.Center) {
                        Image(
                            painter = painterResource(R.drawable.lolo_cat),
                            contentDescription = "لولو AI",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().clip(CircleShape)
                        )
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("لولو AI ✨", color = SoftWhite, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        Text("مساعدك الذكي في المذاكرة ♡", color = MutedPink, fontSize = 13.sp)
                        Text("اسأل، لخّص، افهم، وراجع", color = Color(0xFFD5C5CD), fontSize = 12.sp)
                    }
                    Button(onClick = onLolo, colors = ButtonDefaults.buttonColors(containerColor = Burgundy), shape = RoundedCornerShape(30.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)) {
                        Icon(Icons.Default.ChatBubbleOutline, null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("ابدأ", fontSize = 12.sp)
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 10.dp), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
                BottomItem(Icons.Default.Home, "الرئيسية", true)
                BottomItem(Icons.Default.FolderOpen, "ملفاتي")
                BottomItem(Icons.Default.Pets, "لولو AI", onClick = onLolo)
                BottomItem(Icons.Default.NotificationsNone, "الإشعارات")
                BottomItem(Icons.Default.PersonOutline, "حسابي")
            }
        }
    }

    @Composable
    private fun RoundIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
        Surface(color = Color(0xFF3B1025), shape = CircleShape, modifier = Modifier.size(38.dp).clickable { onClick() }) {
            Box(contentAlignment = Alignment.Center) { Icon(icon, contentDescription = label, tint = SoftWhite, modifier = Modifier.size(20.dp)) }
        }
    }

    @Composable
    private fun BottomItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: Boolean = false, onClick: () -> Unit = {}) {
        Column(Modifier.clickable { onClick() }.padding(horizontal = 3.dp, vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(icon, contentDescription = label, tint = if (selected) MutedPink else Color(0xFF8E828A), modifier = Modifier.size(23.dp))
            Text(label, color = if (selected) MutedPink else Color(0xFF9A8D95), fontSize = 10.sp)
        }
    }

    @Composable
    private fun SubjectScreen(subject: String, files: List<FileItem>, onBack: () -> Unit, onAdd: () -> Unit, onDelete: (FileItem) -> Unit, onOpen: (FileItem) -> Unit) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "رجوع", tint = SoftWhite) }
                Column(Modifier.weight(1f)) {
                    Text(subject, color = SoftWhite, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("${files.size} ملف", color = MutedPink)
                }
                FilledIconButton(onClick = onAdd, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Burgundy)) {
                    Icon(Icons.Default.Add, "إضافة ملف")
                }
            }
            Spacer(Modifier.height(16.dp))
            if (files.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.MenuBook, null, tint = MutedPink, modifier = Modifier.size(54.dp))
                        Text("لسه مفيش ملفات هنا", color = SoftWhite, fontSize = 18.sp)
                        Text("اضغط + لإضافة محاضراتك من الجهاز", color = MutedPink)
                        Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Burgundy)) {
                            Icon(Icons.Default.Add, null); Text("إضافة ملفات")
                        }
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(files, key = { it.uri }) { file ->
                        Card(colors = CardDefaults.cardColors(containerColor = SurfaceGlass), shape = RoundedCornerShape(14.dp)) {
                            Row(Modifier.fillMaxWidth().clickable { onOpen(file) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Description, null, tint = MutedPink)
                                Spacer(Modifier.width(12.dp))
                                Text(file.name, color = SoftWhite, modifier = Modifier.weight(1f))
                                TextButton(onClick = { onDelete(file) }) { Text("إزالة", color = MutedPink) }
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun LoloScreen(onBack: () -> Unit) {
        val engine = remember { LocalLoloEngine() }
        var question by remember { mutableStateOf("") }
        var messages by remember { mutableStateOf(listOf("أهلًا! أنا لولو 🐱. النسخة الحالية واجهة تجريبية؛ لم يتم ربط نموذج ذكاء اصطناعي حقيقي بعد.")) }
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "رجوع", tint = SoftWhite) }
                Column {
                    Text("لولو AI 🐱", color = SoftWhite, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("مساعدك في المذاكرة", color = MutedPink, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages) { message ->
                    Surface(color = SurfaceGlass, shape = RoundedCornerShape(16.dp)) {
                        Text(message, color = SoftWhite, modifier = Modifier.fillMaxWidth().padding(14.dp))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().background(SurfaceGlass, RoundedCornerShape(24.dp)).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(
                    value = question, onValueChange = { question = it },
                    modifier = Modifier.weight(1f).padding(8.dp),
                    textStyle = TextStyle(color = SoftWhite, fontSize = 16.sp),
                    decorationBox = { inner -> if (question.isEmpty()) Text("اكتب سؤالك...", color = MutedPink); inner() }
                )
                IconButton(onClick = {
                    if (question.isNotBlank()) {
                        messages = messages + "أنت: $question" + "لولو: ${engine.answer(question)}"
                        question = ""
                    }
                }) { Icon(Icons.Default.Send, "إرسال", tint = MutedPink) }
            }
        }
    }
}
